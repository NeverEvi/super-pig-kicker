using UnityEngine;
using System.Collections.Generic;

public class Suck : MonoBehaviour
{
    public Transform suckerPoint;

    public float suckRadius = 8f;
    public float pullStrength = 0.75f;
    public float maxPullSpeed = 2.5f;

    [Header("Global Weak Pull")]
    public float globalPullStrength = 0.03f;
    public float globalMaxPullSpeed = 0.5f;

    public LayerMask baconLayer;

    public Vector3 suckedSize = new(0.1f, 0.1f, 0.1f);

    private Collider[] hits = new Collider[64];
    private Dictionary<Rigidbody, Vector3> originalScales = new();

    void FixedUpdate()
    {
        CleanupDestroyedReferences();

        ApplyGlobalWeakPull();
        ApplyStrongRadiusPull();
    }

    void ApplyGlobalWeakPull()
    {
        Rigidbody[] allBodies = FindObjectsByType<Rigidbody>(FindObjectsSortMode.None);

        foreach (Rigidbody rb in allBodies)
        {
            if (rb == null) continue;
            if (!IsInLayerMask(rb.gameObject.layer, baconLayer)) continue;

            float distance = Vector3.Distance(rb.position, suckerPoint.position);

            // only affect bacon OUTSIDE the radius
            if (distance <= suckRadius) continue;

            Vector3 dir = (suckerPoint.position - rb.position).normalized;

            rb.AddForce(dir * globalPullStrength, ForceMode.Acceleration);
            rb.linearVelocity = Vector3.ClampMagnitude(rb.linearVelocity, globalMaxPullSpeed);
        }
    }

    void ApplyStrongRadiusPull()
    {
        int count = Physics.OverlapSphereNonAlloc(
            suckerPoint.position,
            suckRadius,
            hits,
            baconLayer
        );

        for (int i = 0; i < count; i++)
        {
            Collider hit = hits[i];
            if (hit == null) continue;

            Rigidbody rb = hit.GetComponentInParent<Rigidbody>();
            if (rb == null) continue;

            if (!originalScales.ContainsKey(rb))
                originalScales[rb] = rb.transform.localScale;

            Vector3 toPoint = suckerPoint.position - rb.position;
            float distance = toPoint.magnitude;

            if (distance < 0.1f) continue;

            Vector3 dir = toPoint.normalized;

            float distancePercent = 1f - Mathf.Clamp01(distance / suckRadius);
            float strength = pullStrength * Mathf.Lerp(0.25f, 1f, distancePercent);

            rb.AddForce(dir * strength, ForceMode.Acceleration);
            rb.linearVelocity = Vector3.ClampMagnitude(rb.linearVelocity, maxPullSpeed);

            float shrinkStart = 0.6f;
            float scaleT = Mathf.InverseLerp(shrinkStart, 1f, distancePercent);
            scaleT = Mathf.Pow(scaleT, 2.5f);

            Vector3 original = originalScales[rb];
            rb.transform.localScale = Vector3.Lerp(original, suckedSize, scaleT);
        }
    }

    void CleanupDestroyedReferences()
    {
        List<Rigidbody> deadKeys = new();

        foreach (var pair in originalScales)
        {
            if (pair.Key == null)
                deadKeys.Add(pair.Key);
        }

        foreach (Rigidbody rb in deadKeys)
            originalScales.Remove(rb);
    }

    bool IsInLayerMask(int layer, LayerMask mask)
    {
        return (mask.value & (1 << layer)) != 0;
    }

    void OnDrawGizmosSelected()
    {
        if (suckerPoint == null) return;
        Gizmos.DrawWireSphere(suckerPoint.position, suckRadius);
    }
}