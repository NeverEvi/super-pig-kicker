using System.Collections;
using UnityEngine;

public class PassiveBacon : MonoBehaviour
{
    public static PassiveBacon instance;

    [Header("Bacon Settings")]
    public GameObject baconPrefab;      // assign in Inspector
    public float spawnInterval = 60f;   // start at 60 sec
    public float throwForce = 2.2f;     // force to "eject" bacon

    private float timer;
    public bool running = false;
    private void Awake() => instance = this;

    void Update()
    {
        if (!running) return; 
        timer += Time.deltaTime;
        if (timer >= spawnInterval)
        {
            timer = 0f;

            // Spawn the bacon at the trough's position
            Vector3 spawnPos = transform.position + Vector3.up * 0.5f; // slight offset above trough
            GameObject bacon = Instantiate(baconPrefab, spawnPos, Quaternion.identity);

            // Apply a forward force relative to the trough's forward direction
            if (bacon.TryGetComponent<Rigidbody>(out Rigidbody rb))
            {
                float side = Random.Range(-1.25f, 1.25f);
                float oomph = Random.Range(-0.3f, 0.48f);
                Vector3 forceDir = transform.up + transform.forward + transform.right * side;
                rb.AddForce(forceDir.normalized * (throwForce+oomph), ForceMode.Impulse);
            }
        }
    }
}
